# iLearn How - Universal Lesson Player (Production Deployment)

This package contains the complete, production-ready build of the iLearn How Universal Lesson Player. The contents of the `mynextlesson.com` directory are ready to be deployed to any static web hosting service.

## Deployment Instructions

Deploying this application is simple. Upload the **contents** of the `mynextlesson.com` directory to your web host.

**DO NOT upload the `mynextlesson.com` directory itself.** Upload the files and folders *inside* it (`index.html`, `src/`, `dna-templates/`, `production-deploy/`).

### Recommended Services (Drag & Drop)

For the fastest deployment, you can use services that support drag-and-drop folder uploads:

*   **Netlify:** Drag the `mynextlesson.com` folder onto the deploy page of your Netlify site.
*   **Vercel:** Use the `vercel` CLI or drag the `mynextlesson.com` folder to the Vercel dashboard.
*   **Cloudflare Pages:** Create a new project and upload the `mynextlesson.com` folder.

### Manual FTP/SFTP Upload

If you are using a traditional web host, use an FTP or SFTP client (like FileZilla or Cyberduck) to upload the contents of the `mynextlesson.com` directory to your server's public web root (often `public_html`, `www`, or `httpdocs`).

**Directory Structure on Server:**

Your server's root directory should look like this:

```
/
├── index.html
├── src/
│   └── player.js
├── dna-templates/
│   ├── the-sun.json
│   ├── the-moon.json
│   └── the-ocean.json
└── production-deploy/
    └── assets/
        └── avatars/
            ├── kelly/
            └── ken/
```

## How to Use

Once deployed, the application can be accessed with the following URLs:

*   **Default (The Sun):** `https://your-domain.com/`
*   **The Moon Lesson:** `https://your-domain.com/?lesson=the-moon`
*   **The Ocean Lesson:** `https://your-domain.com/?lesson=the-ocean`

The Power User and Developer tools are included in this build for testing and demonstration purposes.
