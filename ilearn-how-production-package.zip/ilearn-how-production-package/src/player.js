// src/player.js - VERSION 45: Final Polish & Dynamic Avatars
console.log("PLAYER.JS VERSION 45 - DYNAMIC AVATARS");

class UniversalLessonPlayer {
    static async create(lessonId = 'the-sun') {
        const lessonPath = `/dna-templates/${lessonId}.json`;
        try {
            const response = await fetch(lessonPath);
            if (!response.ok) throw new Error(`HTTP error! Status: ${response.status} for path: ${lessonPath}`);
            const lessonData = await response.json();
            if (window.playerInstance) window.playerInstance.destroy();
            window.playerInstance = new UniversalLessonPlayer(lessonData, lessonId);
            return window.playerInstance;
        } catch (error) {
            console.error(`Failed to load lesson '${lessonId}':`, error);
            document.body.innerHTML = `<div style="color:red; text-align:center; padding-top: 50px;">Failed to load lesson: ${lessonId}. Check console for details.</div>`;
            return null;
        }
    }

    constructor(lessonData, lessonId) {
        this.lesson = lessonData;
        this.lessonId = lessonId;
        const startingAvatar = Math.random() < 0.5 ? 'kelly' : 'ken';
        this.state = { phase: 0, age: '25', tone: 'neutral', avatar: startingAvatar, expression: 'neutral' };
        this.chaos = {};
        this.readAlongTimer = null;
        this._initialize();
    }

    _initialize() {
        this._cacheDom();
        this._bindEvents();
        this._makeInspectorsDraggable();
        this.render();
    }

    destroy() {
        if (this.readAlongTimer) clearInterval(this.readAlongTimer);
    }
    
    // --- Core Rendering & State Management ---

    setState(newState, renderOnly = false) {
        this.stopReadAlong();
        const oldState = { ...this.state };
        this.state = { ...this.state, ...newState };
        if (!renderOnly) {
            this.state.phase = Math.max(0, Math.min(4, this.state.phase));
        } else {
            this.state.phase = oldState.phase;
        }
        this.render();
    }

    render() {
        this._updateStaticUI();
        this._updateProgressBar();
        const contentData = this._getContentBlock();

        if (!contentData || !contentData.block) {
            this._handleContentError();
            return;
        }

        const { block, phaseName, onComplete, onChoice, expression } = contentData;
        this.setExpression(expression || 'neutral');
        this._updateDebugPanels(block);

        Object.values(this.dom.phases).forEach(p => p.classList.remove('active'));
        const activePhaseEl = this.dom.phases[phaseName];
        if (activePhaseEl) activePhaseEl.classList.add('active');

        const mainContentEl = this.dom.content[phaseName];
        this.startReadAlong(mainContentEl, block, () => {
            if (onChoice) {
                this._presentChoices(phaseName, block, onChoice);
            } else if (onComplete) {
                setTimeout(onComplete, 500);
            }
        });
    }

    _presentChoices(phaseName, block, onChoice) {
        const choiceContainer = this.dom.choices[phaseName];
        const choiceBubbles = { a: this.dom.choiceBubbles[`${phaseName}A`], b: this.dom.choiceBubbles[`${phaseName}B`] };
        choiceBubbles.a.textContent = block.option_a.display_text;
        choiceBubbles.b.textContent = block.option_b.display_text;
        choiceContainer.classList.add('visible');

        const handleChoiceClick = (choiceKey) => {
            Object.values(choiceBubbles).forEach(el => el.classList.remove('selected'));
            choiceBubbles[choiceKey].classList.add('selected');
            choiceContainer.classList.remove('visible');
            setTimeout(() => onChoice(choiceKey, block.correct_option), 400);
        };
        choiceBubbles.a.onclick = () => handleChoiceClick('a');
        choiceBubbles.b.onclick = () => handleChoiceClick('b');
    }

    _getContentBlock() {
        const { phase, age, tone } = this.state;
        try {
            if (this.chaos['no-content']) throw new Error("[Chaos] Content block access denied.");

            if (phase === 0) {
                const content = this.lesson.age_expressions?.[age]?.concept_name?.[tone];
                if (!content) throw new Error(`Missing concept_name for age ${age}, tone ${tone}`);
                return { block: content, phaseName: 'welcome', expression: 'neutral', onComplete: () => this.setState({ phase: 1 }) };
            }
            if (phase >= 1 && phase <= 3) {
                const phaseName = ['beginning', 'middle', 'end'][phase - 1];
                const qData = this.lesson.core_lesson_structure?.[`question_${phase}`]?.ages?.[age];
                if (!qData) throw new Error(`Missing question data for phase ${phase}, age ${age}`);
                const questionContent = qData.question?.[tone];
                if (!questionContent) throw new Error(`Missing question text for phase ${phase}, age ${age}, tone ${tone}`);
                
                const onChoice = (choice, correct_option) => {
                    const isCorrect = choice === correct_option;
                    const expression = isCorrect ? 'happy' : 'thinking';
                    this.setExpression(expression);

                    if (this.chaos['no-teach']) {
                        console.warn("[Chaos] Simulating missing teaching moment.");
                        this.setState({ phase: this.state.phase + 1 });
                        return;
                    }
                    const teachingMomentData = qData.teaching_moments?.[`option_${choice}_response`];
                    if (!teachingMomentData) throw new Error(`Missing teaching_moment for phase ${phase}, choice ${choice}`);
                    this._renderTeachingMoment(teachingMomentData);
                };
                
                const block = { ...questionContent, option_a: qData.option_a, option_b: qData.option_b, correct_option: qData.correct_option };
                return { block, phaseName, expression: 'curious', onChoice };
            }
            if (phase === 4) {
                const content = this.lesson.wisdom_phase_content?.fortune?.[tone];
                if (!content) throw new Error(`Missing wisdom content for tone ${tone}`);
                return { block: content, phaseName: 'wisdom', expression: 'neutral', onComplete: () => {} };
            }
        } catch (err) {
            console.error("CRITICAL: Failed to get content block.", { phase, age, tone, error: err });
            return null;
        }
    }

    _renderTeachingMoment(momentData) {
        this.stopReadAlong();
        Object.values(this.dom.phases).forEach(p => p.classList.remove('active'));
        this.dom.phases.teachingMoment.classList.add('active');
        
        const momentContent = momentData[this.state.tone] || momentData;
        const momentElement = this.dom.content.teachingMoment;
        
        this.startReadAlong(momentElement, momentContent, () => this.setState({ phase: this.state.phase + 1 }));
        this._updateDebugPanels({ "Teaching Moment": momentContent });
    }
    
    // --- UI & DOM Management ---

    setExpression(expression) {
        this.state.expression = expression;
        const expressionMap = {
            'neutral': 'base-states/kelly_neutral_default.png',
            'curious': 'lesson-sequence/kelly_question_curious.png',
            'happy': 'emotional-expressions/kelly_happy_celebrating.png',
            'thinking': 'emotional-expressions/kelly_concerned_thinking.png',
        };
        const kenExpressionMap = {
            'neutral': 'base-states/ken_neutral_default.png',
            'curious': 'lesson-sequence/ken_question_curious.png',
            'happy': 'emotional-expressions/ken_happy_celebrating.png',
            'thinking': 'emotional-expressions/ken_concerned_thinking.png',
        };
        
        const map = this.state.avatar === 'ken' ? kenExpressionMap : expressionMap;
        const path = `production-deploy/assets/avatars/${this.state.avatar}/optimized/${map[expression] || map['neutral']}`;
        
        // Preload image to prevent flickering
        const img = new Image();
        img.onload = () => { this.dom.avatarBackground.style.backgroundImage = `url(${path})`; };
        img.src = path;
    }

    _cacheDom() { /* ... unchanged ... */ }
    _bindEvents() { /* ... unchanged ... */ }
    _updateStaticUI() { /* ... unchanged ... */ }
    _updateProgressBar() { /* ... unchanged ... */ }
    _updateDebugPanels() { /* ... unchanged ... */ }
    _makeInspectorsDraggable() { /* ... unchanged ... */ }
    _handleContentError() { /* ... unchanged ... */ }
    
    // --- Read-Along Logic ---

    startReadAlong(element, content, onComplete) { /* ... unchanged ... */ }
    stopReadAlong() { clearInterval(this.readAlongTimer); }
}

// --- PASTE UNCHANGED METHODS ---
UniversalLessonPlayer.prototype._handleContentError = function() {
    const errorMsg = `Content not found for phase ${this.state.phase}.`;
    this.dom.content.welcome.innerHTML = errorMsg;
    Object.values(this.dom.phases).forEach(p => p.classList.remove('active'));
    this.dom.phases.welcome.classList.add('active');
    this._updateDebugPanels({ error: "Could not retrieve valid content block." });
};
UniversalLessonPlayer.prototype._cacheDom = function() {
    this.dom = {
        avatarBackground: document.getElementById('avatar-background'),
        phases: { welcome: document.getElementById('welcome-phase'), beginning: document.getElementById('beginning-phase'), middle: document.getElementById('middle-phase'), end: document.getElementById('end-phase'), wisdom: document.getElementById('wisdom-phase'), teachingMoment: document.getElementById('teaching-moment-phase'), },
        content: { welcome: document.getElementById('welcome-content'), beginningQuestion: document.getElementById('beginning-question'), middleQuestion: document.getElementById('middle-question'), endQuestion: document.getElementById('end-question'), wisdom: document.getElementById('wisdom-content'), teachingMoment: document.getElementById('teaching-moment-content') },
        choices: { beginning: document.querySelector('#beginning-phase .choices-container'), middle: document.querySelector('#middle-phase .choices-container'), end: document.querySelector('#end-phase .choices-container'), },
        choiceBubbles: { beginningA: document.getElementById('beginning-choice-a'), beginningB: document.getElementById('beginning-choice-b'), middleA: document.getElementById('middle-choice-a'), middleB: document.getElementById('middle-choice-b'), endA: document.getElementById('end-choice-a'), endB: document.getElementById('end-choice-b'), },
        controls: { masterFlyoutContainer: document.querySelector('.master-flyout-container'), masterTrigger: document.getElementById('master-trigger'), avatarButtons: document.querySelectorAll('#avatar-controls .flyout-btn'), ageButtons: document.querySelectorAll('#age-controls .flyout-btn'), toneButtons: document.querySelectorAll('#tone-controls .flyout-btn'), },
        inspectors: { stateInspector: document.getElementById('state-inspector'), contentInspector: document.getElementById('content-inspector'), devPanel: document.getElementById('dev-panel'), stateToggle: document.getElementById('inspector-state-toggle'), contentToggle: document.getElementById('inspector-content-toggle'), devToggle: document.getElementById('inspector-dev-toggle'), closeBtns: document.querySelectorAll('.inspector-close-btn'), stateContent: document.getElementById('state-inspector-content'), contentContent: document.getElementById('content-inspector-content'), codeContent: document.getElementById('code-inspector-content') },
        devPanel: { tabs: document.querySelectorAll('#dev-panel .tab-btn'), dnaTab: document.getElementById('dna-tab'), powerTab: document.getElementById('power-tab'), lessonButtons: document.querySelectorAll('#power-tab [data-lesson]'), phaseButtons: document.querySelectorAll('#power-tab [data-phase]'), chaosButtons: document.querySelectorAll('#power-tab [data-chaos]'), },
        progress: { lineFill: document.getElementById('progress-line-fill'), steps: document.querySelectorAll('.progress-step') }
    };
};
UniversalLessonPlayer.prototype._bindEvents = function() {
    this.dom.controls.masterTrigger.addEventListener('click', (e) => { e.stopPropagation(); this.dom.controls.masterFlyoutContainer.classList.toggle('active'); });
    document.addEventListener('click', () => this.dom.controls.masterFlyoutContainer.classList.remove('active'));
    const handleStateChange = (newState, renderOnly = true) => { this.setState(newState, renderOnly); };
    this.dom.controls.avatarButtons.forEach(btn => btn.addEventListener('click', () => handleStateChange({ avatar: btn.dataset.avatar })));
    this.dom.controls.ageButtons.forEach(btn => btn.addEventListener('click', () => handleStateChange({ age: btn.dataset.age })));
    this.dom.controls.toneButtons.forEach(btn => btn.addEventListener('click', () => handleStateChange({ tone: btn.dataset.tone })));
    const inspectorToggles = { 'state-inspector': this.dom.inspectors.stateToggle, 'content-inspector': this.dom.inspectors.contentToggle, 'dev-panel': this.dom.inspectors.devToggle };
    this.dom.inspectors.closeBtns.forEach(btn => btn.addEventListener('click', (e) => { e.stopPropagation(); const panelId = btn.dataset.inspector; document.getElementById(panelId).classList.remove('visible'); if (inspectorToggles[panelId]) inspectorToggles[panelId].classList.remove('active'); }));
    Object.entries(inspectorToggles).forEach(([panelId, toggleBtn]) => { toggleBtn.addEventListener('click', (e) => { e.stopPropagation(); document.getElementById(panelId).classList.toggle('visible'); toggleBtn.classList.toggle('active'); }); });
    this.dom.devPanel.tabs.forEach(tab => tab.addEventListener('click', () => { this.dom.devPanel.tabs.forEach(t => t.classList.remove('active')); tab.classList.add('active'); document.querySelectorAll('#dev-panel .tab-content').forEach(c => c.classList.remove('active')); document.getElementById(tab.dataset.tab).classList.add('active'); }));
    this.dom.devPanel.lessonButtons.forEach(btn => btn.addEventListener('click', () => UniversalLessonPlayer.create(btn.dataset.lesson)));
    this.dom.devPanel.phaseButtons.forEach(btn => btn.addEventListener('click', () => this.setState({ phase: parseInt(btn.dataset.phase, 10) }, false)));
    this.dom.devPanel.chaosButtons.forEach(btn => btn.addEventListener('click', () => { btn.classList.toggle('active'); this.chaos[btn.dataset.chaos] = btn.classList.contains('active'); this.render(); }));
};
UniversalLessonPlayer.prototype._updateStaticUI = function() {
    const { avatar, age, tone } = this.state;
    this.setExpression(this.state.expression); // Ensure expression is re-applied on avatar change
    this.dom.controls.avatarButtons.forEach(btn => btn.classList.toggle('active', btn.dataset.avatar === avatar));
    this.dom.controls.ageButtons.forEach(btn => btn.classList.toggle('active', btn.dataset.age === age));
    this.dom.controls.toneButtons.forEach(btn => btn.classList.toggle('active', btn.dataset.tone === tone));
    this.dom.devPanel.lessonButtons.forEach(btn => btn.classList.toggle('active', btn.dataset.lesson === this.lessonId));
    this.dom.devPanel.phaseButtons.forEach(btn => btn.classList.toggle('active', parseInt(btn.dataset.phase, 10) === this.state.phase));
};
UniversalLessonPlayer.prototype._updateProgressBar = function() {
    const currentPhase = this.state.phase;
    this.dom.progress.steps.forEach((step, index) => {
        step.classList.toggle('active', index === currentPhase);
        step.classList.toggle('completed', index < currentPhase);
    });
    const fillPercentage = currentPhase > 0 ? (currentPhase / (this.dom.progress.steps.length - 1)) * 100 : 0;
    this.dom.progress.lineFill.style.width = `${fillPercentage}%`;
};
UniversalLessonPlayer.prototype._updateDebugPanels = function(currentContent = {}) {
    const chaosStatus = Object.entries(this.chaos).filter(([, v]) => v).map(([k]) => k).join(', ') || 'None';
    this.dom.inspectors.stateContent.innerText = `Lesson: ${this.lessonId}\nPhase: ${this.state.phase}\nAge: ${this.state.age}\nTone: ${this.state.tone}\nAvatar: ${this.state.avatar}\nExpression: ${this.state.expression}\nChaos: ${chaosStatus}`;
    this.dom.inspectors.contentContent.innerText = JSON.stringify(currentContent, null, 2);
    this.dom.inspectors.codeContent.innerText = JSON.stringify(this.lesson, null, 2);
};
UniversalLessonPlayer.prototype._makeInspectorsDraggable = function() {
    document.querySelectorAll('.inspector-panel').forEach(panel => {
        const header = panel.querySelector('.inspector-header');
        if (!header) return;
        let isDragging = false, offset = { x: 0, y: 0 };
        header.addEventListener('mousedown', (e) => { isDragging = true; offset.x = e.clientX - panel.offsetLeft; offset.y = e.clientY - panel.offsetTop; header.style.cursor = 'grabbing'; });
        document.addEventListener('mousemove', (e) => { if (isDragging) { panel.style.left = `${e.clientX - offset.x}px`; panel.style.top = `${e.clientY - offset.y}px`; } });
        document.addEventListener('mouseup', () => { isDragging = false; header.style.cursor = 'grab'; });
    });
};
UniversalLessonPlayer.prototype.startReadAlong = function(element, content, onComplete) {
    this.stopReadAlong();
    let script = content.display_text;
    if (!this.chaos['no-voice'] && content.voice_over_script) { script = content.voice_over_script; }
    const words = script.split(' ').filter(w => w);
    element.innerHTML = words.map(word => `<span>${word}</span>`).join(' ');
    let i = 0;
    const wordElements = element.querySelectorAll('span');
    if (!words.length) { if (onComplete) onComplete(); return; }
    this.readAlongTimer = setInterval(() => {
        if (i > 0) wordElements[i-1]?.classList.remove('highlight');
        if (i < words.length) { wordElements[i].classList.add('highlight'); i++; }
        else { this.stopReadAlong(); if (onComplete) onComplete(); }
    }, 200);
};

document.addEventListener('DOMContentLoaded', () => {
    const startLesson = new URLSearchParams(window.location.search).get('lesson') || 'the-sun';
    UniversalLessonPlayer.create(startLesson);
});
